class ValueException(Exception):
    pass

class ModeException(Exception):
    pass